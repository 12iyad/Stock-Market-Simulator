Student name: Riyad Hussain
Student number: 20369994

Now complete the statements below for each level you wish to be marked. Replace all text in square brackets.

**IMPORTANT: Please use the "Reset Java Virtual Machine" in Tools to keep the program stable due to the use of Timer
I have adapted this program for blueJ only and will only work on that; it will not function properly on a normal OS terminal**

LEVEL ONE

My code demonstrates inheritance in the following way...

I have a superclass called Assets

This superclass is extended into atleast two subclasses called etfAsset, currencyAsset, companyStock, dividendCompanyStock, cryptoAsset

For each of the named subclasses complete the following...

Subclass 1.

Subclass etfAsset extends the superclass by adding at least one property and its getters and setters. The name of the added property is countryName

this new property are used by the subclass in the following way: As ETF assets are made up of a group of stocks they can be labelled by country of
origin of all stocks in the ETF. When the getName() method is called it can also display the country name or if its a global ETF then itll display Global

Subclass cryptoAsset extends the superclass by overriding the following methods (there must be at least one): getName()

These overridden methods are used in the working code in the following places: StockMarketSimulator.java Line: 259, 358; etfAsset.java Line: 10

Subclass 2.

Subclass currencyAsset extends the superclass by adding at least one property and its getters and setters. The name of the added properties is roundTO

this new properties are used by the subclass in the following way: since foreign exchange ratios are small so 2 decimal places isnt accurant enough so this 
property will change it to 4 decimal places

Subclass currencyAsset extends the superclass by overriding the following methods (there must be at least one): getBuyPrice(), getSellPrice()

These overridden methods are used in the working code in the following places: StockMarketSimulator Line:259, 360; currencyAsset.java Line: 10,13

Subclass 3.

Subclass companyStock extends the superclass but does not add any new properties

Subclass 4.

Subclass dividendCompanyStock extends the superclass by adding the properties dividendDate and dividendYield. These properties are used to find
the amount of dividends you get paid per share and find the date of when to get paid in this case you are paid per x amount of seconds and you
will be notified when you are paid in notifications.

Subclass 5.

Subclass cryptoAsset extends the superclass by adding the properties transactionSize and spread. transactionSize is initialised when creating the
instances and getTransaction() will return a random instances transaction to create a cryptocurrency simulation and "Blockchain" it'll display
the recent transaction made on the blockchain.

LEVEL TWO

Polymorphism consists of the use of the Substitution principle and Late Dynamic binding.

In my code, polymorphism is implemented in at least two places…

Example 1.

The substitution principle can be seen in use in StockMarketSimulator Line: 89. The name of the superclass used in this example is Assets and the subclasses used are companyStock, commodityAsset, currencyAsset, etfAsset.

Late dynamic binding can be seen in StockMarketSimulator Line: 259.

4 subclasses have the same attributes as the superclass Assets so they can all be initialised polymorphically and be all added to 1 array called polyAssets which cleans up the code instead of having
individual arrays for each subclass if they have no extra methods in their own class then I added them into an array for example cryptoAssets had its own array since it contained a method that the 
superclass Aray didn't have so it couldn't be in the array.

Example 2.

The substitution principle can be seen in use in StockMarketSimulator. The name of the superclass used in this example is Assets and the subclasses used are companyStock, commodityAsset, currencyAsset, etfAsset.

Late dynamic binding can be seen in StockMarketSimulator Line: 379. 

This type of polymorphism is used so that a single method can be called that does a calculation and returns a superclass Assets object back to 
where it was called from and assigned to the subclass that called the method which reduces code.
