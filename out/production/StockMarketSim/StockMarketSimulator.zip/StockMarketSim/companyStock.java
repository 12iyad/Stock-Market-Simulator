public class companyStock extends Assets{

    public companyStock(String newAN, double newBP) {
        super(newAN, newBP);

    }

}