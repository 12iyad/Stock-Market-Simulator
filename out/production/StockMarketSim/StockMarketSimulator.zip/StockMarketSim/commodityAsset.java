public class commodityAsset extends Assets{

    public commodityAsset(String newAN, double newBP) {
        super(newAN, newBP);
    }
}